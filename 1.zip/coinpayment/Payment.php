<?php

use Illuminate\Database\Eloquent\Model as Eloquent;

/**
 * Payment
 */
class Payment extends Eloquent
{
    protected $table = "payments";
}