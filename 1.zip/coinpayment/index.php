<?php
header("Location: ../hub");
exit();
?>