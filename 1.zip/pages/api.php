<?php
//Variables de la page
$p="api";
$pageTitle="API";
//End
require_once("../require.php");



include("../include/header2.php");
?>
<main class="api"><h1><i class="fad fa-brackets-curly"></i> API</h1>
	<h2>The API is not yet available !</h2>


<?php include("../include/footer2.php"); ?>